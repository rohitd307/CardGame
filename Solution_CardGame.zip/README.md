Steps to execute the code:
    1. Open command prompt window in the location of the extracted files.
    2. Run command: python <file_name>
       e.g. - python card_game.py (To execute only code)
    3.To run the solution with the testcases install python's unittest framework and then run the python command: python <testFileName>
    e.g. - python test_game.py (To execute solution with test cases)